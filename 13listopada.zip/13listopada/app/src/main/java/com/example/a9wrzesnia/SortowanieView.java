package com.example.a9wrzesnia;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class SortowanieView extends View {

    private int[] tablica;
    private Paint pedzel = new Paint();

    public SortowanieView(Context context, AttributeSet attrs) {
        super(context, attrs);
        pedzel.setColor(Color.BLUE);
    }

    public void ustawTablice(int[] tablica) {
        this.tablica = tablica;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (tablica != null) {
            int szerokosc = getWidth();
            int wysokosc = getHeight();
            float szerokoscSlupka = (float) szerokosc / tablica.length;

            Random random = new Random();
            for (int i = 0; i < tablica.length; i++) {
                float wysokoscSlupka = ((float) tablica[i] / tablica.length) * wysokosc;

                int kolor = random.nextInt(5);
                switch (kolor) {
                    case 0:
                        pedzel.setColor(Color.RED);
                        break;
                    case 1:
                        pedzel.setColor(Color.BLUE);
                        break;
                    case 2:
                        pedzel.setColor(Color.GREEN);
                        break;
                    case 3:
                        pedzel.setColor(Color.YELLOW);
                        break;
                    case 4:
                        pedzel.setColor(Color.BLACK);
                        break;
                }


                canvas.drawRect(i * szerokoscSlupka, wysokosc - wysokoscSlupka, (i + 1) * szerokoscSlupka, wysokosc, pedzel);
            }
        }
    }
}
